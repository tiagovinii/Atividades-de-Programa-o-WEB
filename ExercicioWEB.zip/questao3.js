let dataNascimento = prompt("Digite sua data de nascimento (AAAA-MM-DD):");
let anoNascimento = parseInt(dataNascimento.substring(0, 4));
let dataAtual = new Date();
let anoAtual = dataAtual.getFullYear();
let idade = anoAtual - anoNascimento;

if (idade >= 18) {
  console.log("Você é maior de idade.");
} else {
  console.log("Você é menor de idade.");
}
