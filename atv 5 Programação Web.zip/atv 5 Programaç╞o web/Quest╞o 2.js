function verificarParOuImpar(numero) {
   
    if (numero % 2 === 0) {
        return true; 
    } else {
        return false; 
    }
}

console.log(verificarParOuImpar(4)); 
console.log(verificarParOuImpar(7)); 