function converterParaCaixaAlta(string) {
    return string.toUpperCase();
}


var string1 = "Olá, mundo!";
console.log(converterParaCaixaAlta(string1)); 

var string2 = "JavaScript é incrível!";
console.log(converterParaCaixaAlta(string2)); 

var string3 = "123abc";
console.log(converterParaCaixaAlta(string3));