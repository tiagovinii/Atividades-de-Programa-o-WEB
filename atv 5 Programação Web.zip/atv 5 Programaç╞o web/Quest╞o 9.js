function converterParaBinario(numero) {
    return numero.toString(2);
}

console.log(converterParaBinario(10)); 
console.log(converterParaBinario(27)); 
console.log(converterParaBinario(5)); 
console.log(converterParaBinario(0)); 
console.log(converterParaBinario(255));